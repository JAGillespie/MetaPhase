import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  readonly ROOT_URL = "https://jsonplaceholder.typicode.com/users/";
  posts: any;
  user = [];
  
  constructor(private http: HttpClient) {
  }

  onSubmit(value: number) {
    this.getData(value);
  }

  getData(userId) {
    const qid = userId.uid;
    this.posts = this.http.get(this.ROOT_URL + qid).toPromise()
      .then(data => {
        if (this.user.length!) {
          this.user = [];
          this.user.push(data);
        } else {
          this.user.push(data);
        }
      })
       .catch(err => alert("Error, Please try again later"));
  }
}
